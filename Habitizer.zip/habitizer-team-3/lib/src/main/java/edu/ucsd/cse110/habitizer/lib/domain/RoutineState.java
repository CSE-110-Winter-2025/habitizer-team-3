package edu.ucsd.cse110.habitizer.lib.domain;

public enum RoutineState {
    BEFORE,
    DURING,
    AFTER
}
